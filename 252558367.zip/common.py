'''
Glossary:

- msg ~ message
- chal ~ challenge
- req ~ request
'''

from dataclasses import dataclass
from abc import ABC, abstractmethod
import struct
import os
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM



CLIENT_MSG_SIZE_LIMIT = 2048
SERVER_MSG_SIZE_LIMIT = 2048
TCP_MSG_SIZE_FORMAT = 'H'
CHAL_NONCE_SIZE = 32
CLIENT_ID_FORMAT = 'I'
COOKIE_SIZE = 32
COOKIE_FORMAT = str(COOKIE_SIZE) + 's'
SESSION_ID_FORMAT = 'Q'
ENCRYPT_IV_SIZE = 16
USER_MSG_ENCODING = 'utf_16_le'



class InvalidNetMsg:
    pass

HELLO_MSG = 0

@dataclass
class HelloMsg:
    client_id: int

CHAL_MSG = 1

@dataclass
class ChalMsg:
    nonce: bytes

CHAL_FORMAT = str(CHAL_NONCE_SIZE) + 's'

RESPONSE_MSG = 2

@dataclass
class ResponseMsg:
    client_id: int
    sign: bytes

RESPONSE_FORMAT = CLIENT_ID_FORMAT + '32s'

AUTH_SUCCESS_MSG = 3

@dataclass
class AuthSuccessMsg:
    payload: bytes

AUTH_SUCCESS_FORMAT = COOKIE_FORMAT + 'H'

AUTH_FAIL_MSG = 4

@dataclass
class AuthFailMsg:
    pass

CONNECT_MSG = 5

@dataclass
class ConnectMsg:
    cookie: bytes

CONNECTED_MSG = 6

@dataclass
class ConnectedMsg:
    pass

CHAT_REQ_MSG = 7

@dataclass
class ChatReqMsg:
    client_id: int

CHAT_STARTED_MSG = 8

@dataclass
class ChatStartedMsg:
    session_id: int
    client_id: int

CHAT_STARTED_FORMAT = SESSION_ID_FORMAT + CLIENT_ID_FORMAT

UNREACHABLE_MSG = 9

@dataclass
class UnreachableMsg:
    client_id: int

END_REQ_MSG = 10

@dataclass
class EndReqMsg:
    session_id: int

END_NOTIF_MSG = 11

@dataclass
class EndNotifMsg:
    session_id: int

CHAT_MSG = 12

@dataclass
class ChatMsg:
    session_id: int
    msg: str

def parse_net_msg(b):
    if len(b) < 1:
        return InvalidNetMsg()
    try:
        msg_type = b[0]
        if msg_type == CHAT_MSG:
            format = '<x' + SESSION_ID_FORMAT
            (session_id,) = struct.unpack_from(format, b, 0)
            return ChatMsg(session_id, b[struct.calcsize(format) :].decode(encoding = USER_MSG_ENCODING))
        else:
            return InvalidNetMsg()
    except struct.error:
        return InvalidNetMsg()

def render_net_msg(msg):
    if isinstance(msg, ChatMsg):
        return struct.pack('<B' + SESSION_ID_FORMAT, CHAT_MSG, msg.session_id) + msg.msg.encode(encoding = USER_MSG_ENCODING)
    else:
        return None



def mac_a3(key, data):
    digest = hashes.Hash(hashes.SHA256())
    digest.update(data)
    digest.update(key)
    return digest.finalize()

def mac_a8(key, data):
    digest = hashes.Hash(hashes.SHA256())
    # Nonces are added so this function is different from `mac_a3`.
    # If they are the same, then the client sends the session key in a Response message.
    digest.update(b'3\x03%\x93}\xd9\xd0"\xc0\x84@Xi\x9f\xecK\xdf\xa7e\x10g2\xc7\x953o\x9b\x9b\xb68\x80 ')
    digest.update(data)
    digest.update(b'\x1d\xe6\xa6\xcd\x92\xd4\xed\xdbV\xe6D\xc5\xae\x148\xf6\xdfN\xf7\xec\xd9\xd7b\xf9\xbd\xcc\x8d\x19\xa5\t"\xfb')
    digest.update(key)
    digest.update(b'\x08\x13Cg\xec\xed-\x8b\x84\xc8v\x90h\x9c\x83\xc8a\xa5\xe5\x98\xdc]\xb1F\x9d\xd3|6@\xd1\xc6\x8a')
    return digest.finalize()

def my_encrypt(key, plaintext):
    aesgcm = AESGCM(key)
    iv = os.urandom(ENCRYPT_IV_SIZE)
    return iv + aesgcm.encrypt(iv, plaintext, None)

def my_decrypt(key, ciphertext):
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(ciphertext[:ENCRYPT_IV_SIZE], ciphertext[ENCRYPT_IV_SIZE:], None)



def render_tcp(key, msg):
    ciphertext = my_encrypt(key, msg)
    return struct.pack('<' + TCP_MSG_SIZE_FORMAT, len(ciphertext)) + ciphertext

class Reader:
    @abstractmethod
    def read(self, size):
        pass

class SocketReaderClosed(Exception):
    pass

class SocketReader(Reader):
    def __init__(self, socket0):
        self._socket = socket0
        self._buffer = bytearray()
        self._i = 0

    def buffer_size(self):
        return len(self._buffer) - self._i

    def compact(self):
        self._buffer = self._buffer[self._i :]
        self._i = 0

    def read(self, size):
        if self.buffer_size() < size:
            self.compact()
            while True:
                data = self._socket.recv(4096)
                if len(data) == 0:
                    raise SocketReaderClosed()
                self._buffer.extend(data)
                if self.buffer_size() >= size:
                    break
        i1 = self._i + size
        r = self._buffer[self._i : i1]
        self._i = i1
        return r

def parse_tcp(key, reader):
    format = '<' + TCP_MSG_SIZE_FORMAT
    (size,) = struct.unpack(format, reader.read(struct.calcsize(format)))
    return my_decrypt(key, reader.read(size))
