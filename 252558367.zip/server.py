#!/usr/bin/python

import typing
import sys
import os
import base64
import json
import struct
import socket
import threading

from common import *

def parse_client_msg(b):
    if len(b) < 1:
        return InvalidNetMsg()
    try:
        msg_type = b[0]
        if msg_type == HELLO_MSG:
            return HelloMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        elif msg_type == RESPONSE_MSG:
            (client_id, sign) = struct.unpack('<x' + RESPONSE_FORMAT, b)
            return ResponseMsg(client_id, sign)
        elif msg_type == CONNECT_MSG:
            return ConnectMsg(struct.unpack('<x' + COOKIE_FORMAT, b)[0])
        elif msg_type == CHAT_REQ_MSG:
            return ChatReqMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        elif msg_type == END_REQ_MSG:
            return EndReqMsg(struct.unpack('<x' + SESSION_ID_FORMAT, b)[0])
        else:
            return parse_net_msg(b)
    except struct.error:
        return InvalidNetMsg()

def render_server_msg(msg):
    if isinstance(msg, ChalMsg):
        return struct.pack('<B' + CHAL_FORMAT, CHAL_MSG, msg.nonce)
    elif isinstance(msg, AuthSuccessMsg):
        return struct.pack('<B', AUTH_SUCCESS_MSG) + msg.payload
    elif isinstance(msg, AuthFailMsg):
        return struct.pack('<B', AUTH_FAIL_MSG)
    elif isinstance(msg, ConnectedMsg):
        return struct.pack('<B', CONNECTED_MSG)
    elif isinstance(msg, ChatStartedMsg):
        return struct.pack('<B' + CHAT_STARTED_FORMAT, CHAT_STARTED_MSG, msg.session_id, msg.client_id)
    elif isinstance(msg, UnreachableMsg):
        return struct.pack('<B' + CLIENT_ID_FORMAT, UNREACHABLE_MSG, msg.client_id)
    elif isinstance(msg, EndNotifMsg):
        return struct.pack('<B' + SESSION_ID_FORMAT, END_NOTIF_MSG, msg.session_id)
    else:
        return render_net_msg(msg)



class Logger:
    def __init__(self):
        self._lock = threading.Lock()

    def log(self, s):
        with self._lock:
            print(s, file = sys.stderr)

    def debug(self, s):
        self.log('DEBUG: ' + s)

    def error(self, s):
        self.log('ERROR: ' + s)

    def peer_info(self, s):
        self.log('INFO: peer: ' + s)

    def peer_error(self, s):
        self.log('ERROR: peer: ' + s)

    def peer_error_no_client(self, client_id):
        self.peer_error(f'client {client_id} isn\'t subscribed to the chat service')



class IdGen:
    def __init__(self):
        self._i = 0
    def gen(self):
        r = self._i
        self._i += 1
        return r

@dataclass
class Session:
    i: int
    clients: (int, int)

@dataclass
class ClientSession:
    role: int
    session: Session

@dataclass
class Client:
    i: int
    key: bytes
    cookie: typing.Any = None
    socket0: socket.socket = None
    active_session: Session = None

class Db:
    def __init__(self, clients):
        self.lock = threading.Lock()
        self._clients = dict((k, Client(i = k, key = v['key'])) for k, v in clients.items())
        self.session_id_gen = IdGen()

    def does_client_exist(self, client_id):
        return client_id in self._clients

    def set_cookie(self, client_id, cookie):
        self._clients[client_id].cookie = cookie

    def cookie(self, client_id):
        return self._clients[client_id].cookie

    def client_key(self, client_id):
        return self._clients[client_id].key

    def socket0(self, client_id):
        return self._clients[client_id].socket0

    def is_client_reachable(self, client_id):
        return self.does_client_exist(client_id) and not(self._clients[client_id].socket0 is None)

    def is_client_in_session(self, client_id):
        return not(self._clients[client_id].active_session is None)

    def create_session(self, client_id0, client_id1):
        session_id = self.session_id_gen.gen()
        client0 = self._clients[client_id0]
        client1 = self._clients[client_id1]
        session = Session(session_id, (client0, client1))
        client0.active_session = ClientSession(0, session)
        client1.active_session = ClientSession(1, session)
        return session_id

    def active_session(self, client_id):
        return self._clients[client_id].active_session.session.i

    def _client_peer(self, client_session):
        return client_session.session.clients[1 - client_session.role]

    def client_peer(self, client_id):
        return self._client_peer(self._clients[client_id].active_session).i

    def mark_connected(self, client_id, socket0):
        self._clients[client_id].socket0 = socket0

    def _end_session(self, client):
        client_session = client.active_session
        client.active_session = None
        client1 = self._client_peer(client_session)
        client1.active_session = None
        return client1

    def end_session(self, client_id):
        return self._end_session(self._clients[client_id]).i

    def mark_disconnected(self, client_id):
        client = self._clients[client_id]
        client.socket0 = None
        client_session = client.active_session
        if client_session is None:
            return None
        else:
            client1 = self._end_session(client)
            return (client1.i, client_session.session.i)



class ReadUdpThread(threading.Thread):
    def __init__(self, tcp_port, db, udp_socket, logger):
        super().__init__()
        self.daemon = True
        self.tcp_port = tcp_port
        self.db = db
        self.udp_socket = udp_socket
        self.logger = logger

    def run(self):
        client_chals = dict()
        while True:
            (udp_packet, peer) = self.udp_socket.recvfrom(CLIENT_MSG_SIZE_LIMIT)
            def send(msg):
                self.udp_socket.sendto(render_server_msg(msg), peer)
            msg = parse_client_msg(udp_packet)
            if isinstance(msg, HelloMsg):
                client_id = msg.client_id
                does_client_exist = None
                with self.db.lock:
                    does_client_exist = self.db.does_client_exist(client_id)
                if does_client_exist:
                    chal_nonce = os.urandom(CHAL_NONCE_SIZE)
                    client_chals[(peer, client_id)] = chal_nonce
                    send(ChalMsg(chal_nonce))
                else:
                    self.logger.peer_error_no_client(client_id)
                    send(AuthFailMsg())
            elif isinstance(msg, ResponseMsg):
                client_id = msg.client_id
                chal_id = (peer, client_id)
                if not(chal_id in client_chals):
                    self.logger.peer_error(f'client {client_id} at host {peer} sent a Response message without a corresponding earlier Challenge message')
                else:
                    k = None
                    with self.db.lock:
                        client_key = self.db.client_key(client_id)
                        if mac_a3(client_key, client_chals[chal_id]) != msg.sign:
                            def k1():
                                self.logger.peer_error(f'client {client_id} sent a Response message with an incorrect signature')
                                send(AuthFailMsg())
                            k = k1
                        else:
                            cookie = os.urandom(COOKIE_SIZE)
                            self.db.set_cookie(client_id, cookie)
                            def k1():
                                del client_chals[chal_id]
                                self.logger.peer_info(f'client {client_id} has been authenticated successfully')
                                send(AuthSuccessMsg(my_encrypt(client_key, struct.pack('<' + AUTH_SUCCESS_FORMAT, cookie, self.tcp_port))))
                            k = k1
                    k()
            else:
                self.logger.peer_error(f'unexpected message {msg}')

class ReadTcpThread(threading.Thread):
    def __init__(self, tcp_client_socket, db, logger):
        super().__init__()
        self.daemon = True
        self.socket0 = tcp_client_socket
        self.db = db
        self.logger = logger

    def run(self):
        try:
            reader = SocketReader(self.socket0)
            try:
                format = '<' + CLIENT_ID_FORMAT
                (client_id,) = struct.unpack(format, reader.read(struct.calcsize(format)))
                client_key = None
                cookie = None
                with self.db.lock:
                    if self.db.does_client_exist(client_id):
                        client_key = self.db.client_key(client_id)
                        cookie = self.db.cookie(client_id)
                if cookie is None:
                    self.logger.peer_error(f'client {client_id} has no cookie set')
                else:
                    def send(msg):
                        return self.socket0.sendall(render_tcp(client_key, render_server_msg(msg)))
                    def send_to(client_id, msg):
                        return self.db.socket0(client_id).sendall(render_tcp(self.db.client_key(client_id), render_server_msg(msg)))
                    msg = parse_client_msg(parse_tcp(client_key, reader))
                    if not(isinstance(msg, ConnectMsg)):
                        self.logger.peer_error('a Connect message is expected')
                    elif msg.cookie != cookie:
                        self.logger.peer_error(f'client {client_id} sent an incorrect cookie')
                    else:
                        self.logger.peer_info(f'client {client_id} has connected via TCP')
                        with self.db.lock:
                            self.db.mark_connected(client_id, self.socket0)
                            send(ConnectedMsg())
                        try:
                            while True:
                                msg = parse_client_msg(parse_tcp(client_key, reader))
                                if isinstance(msg, ChatReqMsg):
                                    client_id1 = msg.client_id
                                    def unreachable():
                                        send(UnreachableMsg(client_id1))
                                    with self.db.lock:
                                        if not(self.db.is_client_reachable(client_id1)):
                                            self.logger.peer_error(f'client {client_id1} is unreachable')
                                            unreachable()
                                        elif client_id1 == client_id:
                                            self.logger.peer_error(f'client {client_id} tries to chat with themselves')
                                            unreachable()
                                        elif self.db.is_client_in_session(client_id):
                                            self.logger.peer_error(f'client {client_id} already chats')
                                            unreachable()
                                        elif self.db.is_client_in_session(client_id1):
                                            self.logger.peer_error(f'client {client_id1} already chats')
                                            unreachable()
                                        else:
                                            session_id = self.db.create_session(client_id, client_id1)
                                            send(ChatStartedMsg(session_id, client_id1))
                                            send_to(client_id1, ChatStartedMsg(session_id, client_id))
                                elif isinstance(msg, EndReqMsg):
                                    with self.db.lock:
                                        if not(self.db.is_client_in_session(client_id)):
                                            self.logger.peer_error(f'client {client_id} tries to end a session while not in a session')
                                        else:
                                            session_id = self.db.active_session(client_id)
                                            if msg.session_id != session_id:
                                                self.logger.peer_error(f'client {client_id} isn\'t in session {session_id}')
                                            else:
                                                client_id1 = self.db.end_session(client_id)
                                                send_to(client_id1, EndNotifMsg(session_id))
                                elif isinstance(msg, ChatMsg):
                                    with self.db.lock:
                                        if not(self.db.is_client_in_session(client_id)):
                                            self.logger.peer_error(f'client {client_id} tries to chat while not in a session')
                                        else:
                                            session_id = self.db.active_session(client_id)
                                            if msg.session_id != session_id:
                                                self.logger.peer_error(f'client {client_id} tries to chat in wrong session {msg.session_id}')
                                            else:
                                                send_to(self.db.client_peer(client_id), ChatMsg(session_id, msg.msg))
                                else:
                                    self.logger.peer_error(f'unexpected message {msg}')
                        finally:
                            with self.db.lock:
                                r = self.db.mark_disconnected(client_id)
                                if not(r is None):
                                    (client_id1, session_id) = r
                                    send_to(client_id1, EndNotifMsg(session_id))
            except SocketReaderClosed:
                self.logger.peer_info(f'client has disconnected')
        finally:
            self.socket0.close()

def main_net(conf):
    logger = Logger()
    db = Db(conf['clients'])

    udp_socket = socket.socket(type = socket.SOCK_DGRAM)
    udp_socket.bind((conf['host'], conf['udp_port']))
    ReadUdpThread(conf['tcp_port'], db, udp_socket, logger).start()

    with socket.socket(type = socket.SOCK_STREAM) as server_tcp_socket:
        server_tcp_socket.bind((conf['host'], conf['tcp_port']))
        server_tcp_socket.listen()
        while True:
            (client_tcp_socket, _) = server_tcp_socket.accept()
            try:
                ReadTcpThread(client_tcp_socket, db, logger).start()
            except Exception as e:
                client_tcp_socket.close()
                logger.error('failed to start a TCP reading thread')
                logger.error(str(e))

def main():
    try:
        [_, conf] = sys.argv
        with open(conf, 'r') as file0:
            try:
                conf = json.load(file0)
                def client_parse(client):
                    client['key'] = base64.standard_b64decode(client['key'])
                    return client
                conf['clients'] = dict((int(k), client_parse(v)) for k, v in conf['clients'].items())
                main_net(conf)
            except ValueError as e:
                print('ERROR: invalid configuration file: ' + str(e), file = sys.stderr)
    except ValueError:
        print('Usage: $this_program $path_to_configuration_file')

if __name__ == '__main__':
    main()
