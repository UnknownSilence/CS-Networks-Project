#!/usr/bin/python

'''Threading.

The main thread reads user input from `stdin`. When the client is connected to the server via TCP,
the main thread starts the `TcpThread` which reads from the TCP socket connected to the server.

The client contains a database `Db` which stores, for example,
the identifier of the active chat session that this client is participating in.
Since multiple threads work with the `Db`,
the `Db` contains a `threading.Lock` which should be obtained before working with this `Db`.
For simplicity, the whole database is protected with one `threading.Lock`.

The writing end of the TCP socket, `stdout`, and `stderr` are considered part of the `Db`.
Before writing to them, one must obtain the `threading.Lock` of the `Db`.
This is true for `log*` functions too.'''

from dataclasses import dataclass
import sys
import sys as _sys
import base64
import json
import struct
import cryptography
import socket
import threading

from common import *

def parse_server_msg(b):
    '''Returns a Python representation (a `NetMsg`) of a net message `b`.
    `b` is a bytes-like object. This function only handles messages sent by servers.'''
    if len(b) < 1:
        return InvalidNetMsg()
    msg_type = b[0]
    try:
        if msg_type == CHAL_MSG_TAG:
            return ChalMsg(struct.unpack('<x' + CHAL_FORMAT, b)[0])
        elif msg_type == AUTH_SUCCESS_MSG_TAG:
            return AuthSuccessMsg(b[1:])
        elif msg_type == AUTH_FAIL_MSG_TAG:
            struct.unpack('<x', b)
            return AuthFailMsg()
        elif msg_type == CONNECTED_MSG_TAG:
            struct.unpack('<x', b)
            return ConnectedMsg()
        elif msg_type == CHAT_STARTED_MSG_TAG:
            (session_id, client_id) = struct.unpack('<x' + CHAT_STARTED_FORMAT, b)
            return ChatStartedMsg(session_id, client_id)
        elif msg_type == UNREACHABLE_MSG_TAG:
            return UnreachableMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        elif msg_type == END_NOTIF_MSG_TAG:
            return EndNotifMsg(struct.unpack('<x' + SESSION_ID_FORMAT, b)[0])
        elif msg_type == HISTORY_RESP_MSG_TAG:
            format = '<x' + HISTORY_RESP_FORMAT
            (session_id, client_id) = struct.unpack_from(format, b, 0)
            text = b[struct.calcsize(format) :].decode(encoding = USER_MSG_ENCODING)
            return HistoryRespMsg(session_id, client_id, text)
        else:
            return parse_net_msg(b)
    except struct.error:
        return InvalidNetMsg()

def render_client_msg(msg):
    '''Converts a Python representation `msg` of a net message into this message 
    Returns a bytes-like object.
    This function only handles messages sent by clients.'''
    if isinstance(msg, HelloMsg):
        return struct.pack('<B' + CLIENT_ID_FORMAT, HELLO_MSG_TAG, msg.client_id)
    elif isinstance(msg, ResponseMsg):
        return struct.pack('<B' + RESPONSE_FORMAT, RESPONSE_MSG_TAG, msg.client_id, msg.sign)
    elif isinstance(msg, ConnectMsg):
        return struct.pack('<B' + COOKIE_FORMAT, CONNECT_MSG_TAG, msg.cookie)
    elif isinstance(msg, ChatReqMsg):
        return struct.pack('<B' + CLIENT_ID_FORMAT, CHAT_REQ_MSG_TAG, msg.client_id)
    elif isinstance(msg, EndReqMsg):
        return struct.pack('<B' + SESSION_ID_FORMAT, END_REQ_MSG_TAG, msg.session_id)
    elif isinstance(msg, HistoryReqMsg):
        return struct.pack('<B' + CLIENT_ID_FORMAT, HISTORY_REQ_MSG_TAG, msg.client_id)
    else:
        return render_net_msg(msg)

def log(s):
    if _sys:
        # if it isn't shutdown
        print(s, file = sys.stderr)

def log_error(s):
    log('ERROR: ' + s)

def log_peer_error(s):
    log_error('peer: ' + s)

def log_peer_info(s):
    log('INFO: peer: ' + s)

def print_to_user(s):
    print(s)
    sys.stdout.flush()

def recv_from_peer(socket0, size, peer):
    '''Reads packets from UDP `socket0` until it receives a packet from `peer`.
    Then returns this packet. `size` shall be the maximum size in bytes of a packet.
    `peer` shall be of the form `(IP_address, UDP_port)`.'''
    while True:
        (udp_packet, peer1) = socket0.recvfrom(size)
        if peer1 == peer:
            return udp_packet



@dataclass
class ClientState:
    pass

@dataclass
class ClientStateInactive(ClientState):
    '''The client doesn't participate in a chat session.'''
    pass

@dataclass
class ClientStateActivating(ClientState):
    '''The client is requesting a chat session.
    In other words, the client has sent the `CHAT_REQUEST` message and awaits a response.'''
    pass

@dataclass
class ClientStateActive(ClientState):
    '''The client is participation in the chat session `session_id`.'''
    session_id: int

class Db:
    def __init__(self):
        self.lock = threading.Lock()
        self.state = ClientStateInactive()



class TcpThread(threading.Thread):
    def __init__(self, socket0, temp_key, db):
        super().__init__()
        self.daemon = True
        self.socket0 = socket0
        self.temp_key = temp_key
        self.db = db

    def handle_msg(self, msg):
        if isinstance(msg, ChatStartedMsg):
            with self.db.lock:
                if isinstance(self.db.state, ClientStateActive):
                    log_peer_error(f'the server is trying to start a chat'\
                            + ' while the chat is already active')
                else:
                    self.db.state = ClientStateActive(msg.session_id)
                    print_to_user(f'Chat started with client {msg.client_id}')
        elif isinstance(msg, UnreachableMsg):
            with self.db.lock:
                if isinstance(self.db.state, ClientStateActivating):
                    self.db.state = ClientStateInactive()
                    print_to_user(f'Client {msg.client_id} is unreachable')
                else:
                    log_peer_error(f'received an Unreachable message without'\
                            + ' a corresponding ChatReq message')
        elif isinstance(msg, EndNotifMsg):
            with self.db.lock:
                if not(isinstance(self.db.state, ClientStateActive)):
                    log_peer_error(f'received an EndNotif message while no chat is active')
                else:
                    if msg.session_id != self.db.state.session_id:
                        log_peer_error(f'the session in the EndNotif message'\
                                + ' doesn\'t match the current session')
                    self.db.state = ClientStateInactive()
                    print_to_user('Chat ended')
        elif isinstance(msg, ChatMsg):
            with self.db.lock:
                if isinstance(self.db.state, ClientStateActive):
                    print_to_user(msg.msg)
                else:
                    log_peer_info(f'received a Chat message'\
                            + ' while the chat isn\'t active')
        elif isinstance(msg, HistoryRespMsg):
            with self.db.lock:
                print_to_user(f'{msg.session_id} from: {msg.client_id} {msg.msg}')
        else:
            with self.db.lock:
                log_peer_error(f'unexpected message {msg}')

    def run(self):
        reader = SocketReader(self.socket0)
        try:
            msg = parse_server_msg(parse_tcp(self.temp_key, reader))
            if not(isinstance(msg, ConnectedMsg)):
                with self.db.lock:
                    log_peer_error('a Connected message is expected')
            else:
                while True:
                    self.handle_msg(parse_server_msg(parse_tcp(self.temp_key, reader)))
        except SocketReaderClosed:
            with self.db.lock:
                log_peer_info('server has disconnected')

def main_tcp(conf, temp_key, cookie, tcp_port):
    '''Starts the `TcpThread`. Reads user input.'''
    db = Db()
    tcp_socket = socket.socket(type = socket.SOCK_STREAM)
    def send(msg):
        return send_tcp(tcp_socket, temp_key, render_client_msg(msg))
    try:
        tcp_socket.connect((conf['server_host'], tcp_port))
        tcp_socket.sendall(struct.pack('<' + CLIENT_ID_FORMAT, conf['id']))
        send(ConnectMsg(cookie))
        TcpThread(tcp_socket, temp_key, db).start()

        while True:
            CHAT_REQ_CMD_PREFIX = 'Chat '
            HISTORY_REQ_CMD_PREFIX = 'History '
            try:
                input0 = input()
            except EOFError:
                break
            if input0 == 'Log off':
                break
            elif input0.startswith(CHAT_REQ_CMD_PREFIX):
                with db.lock:
                    db.state = ClientStateActivating()
                    send(ChatReqMsg(int(input0[len(CHAT_REQ_CMD_PREFIX) :])))
            elif input0 == 'End chat':
                with db.lock:
                    if not(isinstance(db.state, ClientStateActive)):
                        log_error('Chat isn\'t active')
                    else:
                        send(EndReqMsg(db.state.session_id))
            elif input0.startswith(HISTORY_REQ_CMD_PREFIX):
                with db.lock:
                    send(HistoryReqMsg(int(input0[len(HISTORY_REQ_CMD_PREFIX) :])))
            else:
                with db.lock:
                    if not(isinstance(db.state, ClientStateActive)):
                        log_error('Chat isn\'t active')
                    else:
                        send(ChatMsg(db.state.session_id, input0))
    finally:
        tcp_socket.close()

def main_net(conf):
    input0 = input()
    if input0 == 'Log on':
        client_id = conf['id']
        peer = (conf['server_host'], conf['server_udp_port'])
        with socket.socket(type = socket.SOCK_DGRAM) as udp_socket:
            udp_socket.bind(('localhost', 0)) # Binds to some free port, not port `0`.

            def send(msg):
                return udp_socket.sendto(render_client_msg(msg), peer)
            def recv():
                '''`recv_from_peer` only returns packets from `peer`. For this filter
                to work correctly, the first component of `peer` should be an IP address,
                not a domain name.'''
                return parse_server_msg(recv_from_peer(udp_socket, SERVER_MSG_SIZE_LIMIT, peer))
            send(HelloMsg(client_id))
            chal_msg = recv()
            if isinstance(chal_msg, AuthFailMsg):
                print_to_user('This client isn\'nt subscribed to the chat service')
            elif isinstance(chal_msg, ChalMsg):
                client_chal = chal_msg.nonce
                send(ResponseMsg(client_id, mac_a3(conf['key'], client_chal)))
                auth_msg = recv()
                if isinstance(auth_msg, AuthFailMsg):
                    print_to_user('Authentification failed')
                elif isinstance(auth_msg, AuthSuccessMsg):
                    try:
                        temp_key = mac_a8(conf['key'], client_chal)
                        plaintext = my_decrypt(temp_key, auth_msg.payload)
                        (cookie, tcp_port) = struct.unpack('<' + AUTH_SUCCESS_FORMAT, plaintext)
                        main_tcp(conf, temp_key, cookie, tcp_port)
                    except (cryptography.exceptions.InvalidTag, cryptography.exceptions.InvalidKey):
                        log_peer_error('error when decrypting an AuthSuccess message')
                else:
                    log_peer_error('an AuthFail or AuthSuccess message is expected')
            else:
                log_peer_error('an AuthFail or Challenge message is expected')

def main():
    '''Parses a configuration file.'''
    try:
        [_, conf] = sys.argv
        with open(conf, 'r') as file0:
            try:
                conf = json.load(file0)
                conf['key'] = base64.standard_b64decode(conf['key'])
                main_net(conf)
            except ValueError as e:
                print('invalid configuration file', file = sys.stderr)
                print(e)
    except ValueError:
        print('Usage: $this_program $path_to_configuration_file')
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    main()
