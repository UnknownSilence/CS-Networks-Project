'''
Glossary:

- msg ~ message
- chal ~ challenge
- temp key ~ temporary key
- req ~ request
- resp ~ response
- id ~ identifier

A temporary key is used in only one TCP session. It's also called an ephemeral key.
'''

'''Encoding net messages.
Every net message starts with a byte which determines the type of this message.
`*_MSG_TAG` is a value of this byte. Message types are `HELLO`, `AUTH_FAIL`, and so on.
There are functions which convert net messages into their Python representations and backward.
Python representations are objects of class `NetMsg`.
There is a subclass of `NetMsg` for every message type.
Python representations hold message parameters as Python values (`int`, `str`, and so on).

When a net message is transmitted via UDP, it's sent as a UDP packet.
When a net message is transmitted via TCP, we send a length of the message
in format `TCP_MSG_SIZE_FORMAT`, then the message itself.
Hence the receiving host can split the TCP stream of bytes into messages.
Encoding messages for TCP is implemented in `render_tcp` and `parse_tcp`.

Client identifier is an integer number. Session identifier is an integer number.'''

from dataclasses import dataclass
from abc import ABC, abstractmethod
import struct
import os
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM



# maximum size of a client net message
CLIENT_MSG_SIZE_LIMIT = 2048

# maximum size of a server net message
SERVER_MSG_SIZE_LIMIT = 2048

'''Constants for parsing net messages. `*_FORMAT` is a format according to the `struct` library.
`*_SIZE` is a size in bytes.'''

TCP_MSG_SIZE_FORMAT = 'H'
CHAL_NONCE_SIZE = 32
CLIENT_ID_FORMAT = 'I'
COOKIE_SIZE = 32
COOKIE_FORMAT = str(COOKIE_SIZE) + 's'
SESSION_ID_FORMAT = 'Q'
ENCRYPT_IV_SIZE = 16
USER_MSG_ENCODING = 'utf_16_le'

class NetMsg:
    pass

class InvalidNetMsg(NetMsg):
    pass

HELLO_MSG_TAG = 0

@dataclass
class HelloMsg(NetMsg):
    client_id: int

CHAL_MSG_TAG = 1

@dataclass
class ChalMsg(NetMsg):
    nonce: bytes

CHAL_FORMAT = str(CHAL_NONCE_SIZE) + 's'

RESPONSE_MSG_TAG = 2

@dataclass
class ResponseMsg(NetMsg):
    client_id: int
    sign: bytes

RESPONSE_FORMAT = CLIENT_ID_FORMAT + '32s'

AUTH_SUCCESS_MSG_TAG = 3

@dataclass
class AuthSuccessMsg(NetMsg):
    payload: bytes

AUTH_SUCCESS_FORMAT = COOKIE_FORMAT + 'H'

AUTH_FAIL_MSG_TAG = 4

@dataclass
class AuthFailMsg(NetMsg):
    pass

CONNECT_MSG_TAG = 5

@dataclass
class ConnectMsg(NetMsg):
    cookie: bytes

CONNECTED_MSG_TAG = 6

@dataclass
class ConnectedMsg(NetMsg):
    pass

CHAT_REQ_MSG_TAG = 7

@dataclass
class ChatReqMsg(NetMsg):
    client_id: int

CHAT_STARTED_MSG_TAG = 8

@dataclass
class ChatStartedMsg(NetMsg):
    session_id: int
    client_id: int

CHAT_STARTED_FORMAT = SESSION_ID_FORMAT + CLIENT_ID_FORMAT

UNREACHABLE_MSG_TAG = 9

@dataclass
class UnreachableMsg(NetMsg):
    client_id: int

END_REQ_MSG_TAG = 10

@dataclass
class EndReqMsg(NetMsg):
    session_id: int

END_NOTIF_MSG_TAG = 11

@dataclass
class EndNotifMsg(NetMsg):
    session_id: int

CHAT_MSG_TAG = 12

@dataclass
class ChatMsg(NetMsg):
    session_id: int
    msg: str

HISTORY_REQ_MSG_TAG = 13

@dataclass
class HistoryReqMsg(NetMsg):
    client_id: int

HISTORY_RESP_MSG_TAG = 14

@dataclass
class HistoryRespMsg(NetMsg):
    session_id: int
    client_id: int
    msg: str

HISTORY_RESP_FORMAT = SESSION_ID_FORMAT + CLIENT_ID_FORMAT

def parse_net_msg(b):
    '''Returns a Python representation (a `NetMsg`) of a net message `b`.
    `b` is a bytes-like object. This function only handles messages
    common for clients and servers.'''
    if len(b) < 1:
        return InvalidNetMsg()
    try:
        msg_type = b[0]
        if msg_type == CHAT_MSG_TAG:
            format = '<x' + SESSION_ID_FORMAT
            (session_id,) = struct.unpack_from(format, b, 0)
            text = b[struct.calcsize(format) :].decode(encoding = USER_MSG_ENCODING)
            return ChatMsg(session_id, text)
        else:
            return InvalidNetMsg()
    except struct.error:
        return InvalidNetMsg()

def render_net_msg(msg):
    '''Converts a Python representation `msg` of a net message into this message 
    Returns a bytes-like object.
    This function only handles messages common for clients and servers.'''
    if isinstance(msg, ChatMsg):
        return struct.pack('<B' + SESSION_ID_FORMAT, CHAT_MSG_TAG, msg.session_id)\
                + msg.msg.encode(encoding = USER_MSG_ENCODING)
    else:
        return None



def mac_a3(key, data):
    digest = hashes.Hash(hashes.SHA256())
    digest.update(data)
    digest.update(key)
    return digest.finalize()

def mac_a8(key, data):
    digest = hashes.Hash(hashes.SHA256())
    # Nonces are added so this function is different from `mac_a3`.
    # If they are the same, then the client sends the session key in a Response message.
    digest.update(b'3\x03%\x93}\xd9\xd0"\xc0\x84@Xi\x9f\xecK\xdf\xa7e\x10g2\xc7\x953o\x9b\x9b\xb68\x80 ')
    digest.update(data)
    digest.update(b'\x1d\xe6\xa6\xcd\x92\xd4\xed\xdbV\xe6D\xc5\xae\x148\xf6\xdfN\xf7\xec\xd9\xd7b\xf9\xbd\xcc\x8d\x19\xa5\t"\xfb')
    digest.update(key)
    digest.update(b'\x08\x13Cg\xec\xed-\x8b\x84\xc8v\x90h\x9c\x83\xc8a\xa5\xe5\x98\xdc]\xb1F\x9d\xd3|6@\xd1\xc6\x8a')
    return digest.finalize()

def my_encrypt(key, plaintext):
    aesgcm = AESGCM(key)
    iv = os.urandom(ENCRYPT_IV_SIZE)
    return iv + aesgcm.encrypt(iv, plaintext, None)

def my_decrypt(key, ciphertext):
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(ciphertext[:ENCRYPT_IV_SIZE], ciphertext[ENCRYPT_IV_SIZE:], None)



def render_tcp(key, msg):
    ciphertext = my_encrypt(key, msg)
    return struct.pack('<' + TCP_MSG_SIZE_FORMAT, len(ciphertext)) + ciphertext

class Reader:
    @abstractmethod
    def read(self, size):
        pass

class SocketReaderClosed(Exception):
    pass

class SocketReader(Reader):
    '''A TCP socket returns data packets of unpredictable size.
    An object of this class concatenates data packets returned by a TCP socket
    and cuts data packets of desired sizes.'''

    def __init__(self, socket0):
        '''Stores `socket0` in this object.'''
        self._socket = socket0
        self._buffer = bytearray()
        self._i = 0

    def buffer_size(self):
        return len(self._buffer) - self._i

    def compact(self):
        self._buffer = self._buffer[self._i :]
        self._i = 0

    def read(self, size):
        '''Reads a data packet of `size` bytes from the socket inside this object.
        Raises a `SocketReaderClosed` exception if the reading end of the socket was shut down.
        May block.'''
        if self.buffer_size() < size:
            self.compact()
            while True:
                data = self._socket.recv(4096)
                if len(data) == 0:
                    raise SocketReaderClosed()
                self._buffer.extend(data)
                if self.buffer_size() >= size:
                    break
        i1 = self._i + size
        r = self._buffer[self._i : i1]
        self._i = i1
        return r

def parse_tcp(key, reader):
    format = '<' + TCP_MSG_SIZE_FORMAT
    (size,) = struct.unpack(format, reader.read(struct.calcsize(format)))
    return my_decrypt(key, reader.read(size))

def send_tcp(socket0, key, msg):
    return socket0.sendall(render_tcp(key, msg))
