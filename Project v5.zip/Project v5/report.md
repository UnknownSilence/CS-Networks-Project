---
title: "Server Based Chat"
subtitle: "Report"
---

# Protocol

## Connection phase

The client protocol state diagram of the connection phase and the sequence diagram of the connection phase is shown in the assignment handout.

The server protocol state diagram of the connection phase.

## Chat phase

The client protocol state diagram of the chat phase is shown in the assignment handout.

The server protocol state diagram of the chat phase.

The sequence diagram of the unsuccessful chat phase.

The sequence diagram of the successful chat phase.

Incorrect `RESPONSE` doesn't change the state because an attacker can send such a message. We shouldn't let the attacker disrupt the authentication process of a legitimate user.

# Issues

TCP client_id isn't known

chat shitory sesssion id

TCP shut down

lost last chat messages