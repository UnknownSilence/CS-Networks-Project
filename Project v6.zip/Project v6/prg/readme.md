---
title: "Server Based Chat"
subtitle: "Running the program"
---

File “client.py” is the executable Python file of the client. It accepts one argument
which is the path to a client configuration file.
An example of a client configuration file is given in file “client0.conf”
which is mostly self-explanatory. Field “server_host” shall be an IP address.
Field “id” is the identifier of the client.

The client's secret key shall be of size 256 bits. Field “key” of the client configuration file
is the Base64-encoded representation of the client's secret key. Such a representation may be obtained
by executing Python command `base64.standard_b64encode(key)` where `key` is the client's secret key
as a bytes-like object.

File “server.py” is the executable Python file of the server. It accepts one argument
which is the path to a server configuration file.
An example of a server configuration file is given in file “server.conf”
which is mostly self-explanatory.

Field “clients” in a server configuration file is the dictionary of clients
subscribed to the chat service. It consists of records of the form

```
$CLIENT_ID: {"key": $CLIENT_KEY}
```

Such a record shall be copied from a client configuration file, in particular,
`$CLIENT_ID` shall be copied from field “id”, and `$CLIENT_KEY` shall be copied from field “key”.

“client.py” and “server.py” use “common.py”.
