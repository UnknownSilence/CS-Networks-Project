#!/usr/bin/python

'''Threading.

The server uses OS threads to work with multiple clients.

The server contains a database `Db` which stores client profiles, active chat session,
chat history, and such. Since multiple threads work with the `Db`,
the `Db` contains a `threading.Lock` which should be obtained before working with this `Db`.
For simplicity, the whole database is protected with one `threading.Lock`.

The main thread creates `UdpThread` which handles UDP communication.
The main thread works with the listening TCP socket and creates a `TcpThread`
for every connected client.
`TcpThread` created for a client only reads from a TCP socket connected to this client.
Any `TcpThread` can write to any TCP socket. Writing ends of TCP sockets are considered
part of the `Db`. Before writing to a TCP socket, one must obtain the `threading.Lock`
of the `Db`.'''

import typing
from dataclasses import dataclass, field
import sys
import os
import base64
import json
import struct
import socket
import threading

from common import *



def parse_client_msg(b):
    '''Returns a Python representation (a `NetMsg`) of a net message `b`.
    `b` is a bytes-like object. This function only handles messages sent by clients.'''
    if len(b) < 1:
        return InvalidNetMsg()
    try:
        msg_type = b[0]
        if msg_type == HELLO_MSG_TAG:
            return HelloMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        elif msg_type == RESPONSE_MSG_TAG:
            (client_id, sign) = struct.unpack('<x' + RESPONSE_FORMAT, b)
            return ResponseMsg(client_id, sign)
        elif msg_type == CONNECT_MSG_TAG:
            return ConnectMsg(struct.unpack('<x' + COOKIE_FORMAT, b)[0])
        elif msg_type == CHAT_REQ_MSG_TAG:
            return ChatReqMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        elif msg_type == END_REQ_MSG_TAG:
            return EndReqMsg(struct.unpack('<x' + SESSION_ID_FORMAT, b)[0])
        elif msg_type == HISTORY_REQ_MSG_TAG:
            return HistoryReqMsg(struct.unpack('<x' + CLIENT_ID_FORMAT, b)[0])
        else:
            return parse_net_msg(b)
    except struct.error:
        return InvalidNetMsg()

def render_server_msg(msg):
    '''Converts a Python representation `msg` of a net message into this message 
    Returns a bytes-like object.
    This function only handles messages sent by servers.'''
    if isinstance(msg, ChalMsg):
        return struct.pack('<B' + CHAL_FORMAT, CHAL_MSG_TAG, msg.nonce)
    elif isinstance(msg, AuthSuccessMsg):
        return struct.pack('<B', AUTH_SUCCESS_MSG_TAG) + msg.payload
    elif isinstance(msg, AuthFailMsg):
        return struct.pack('<B', AUTH_FAIL_MSG_TAG)
    elif isinstance(msg, ConnectedMsg):
        return struct.pack('<B', CONNECTED_MSG_TAG)
    elif isinstance(msg, ChatStartedMsg):
        return struct.pack('<B' + CHAT_STARTED_FORMAT,\
                CHAT_STARTED_MSG_TAG, msg.session_id, msg.client_id)
    elif isinstance(msg, UnreachableMsg):
        return struct.pack('<B' + CLIENT_ID_FORMAT, UNREACHABLE_MSG_TAG, msg.client_id)
    elif isinstance(msg, EndNotifMsg):
        return struct.pack('<B' + SESSION_ID_FORMAT, END_NOTIF_MSG_TAG, msg.session_id)
    if isinstance(msg, HistoryRespMsg):
        return struct.pack('<B' + HISTORY_RESP_FORMAT,\
                HISTORY_RESP_MSG_TAG, msg.session_id, msg.client_id)\
                + msg.msg.encode(encoding = USER_MSG_ENCODING)
    else:
        return render_net_msg(msg)



class Logger:
    def __init__(self):
        self._lock = threading.Lock()

    def log(self, s):
        with self._lock:
            print(s, file = sys.stderr)

    def debug(self, s):
        self.log('DEBUG: ' + s)

    def error(self, s):
        self.log('ERROR: ' + s)

    def peer_info(self, s):
        self.log('INFO: peer: ' + s)

    def peer_error(self, s):
        self.log('ERROR: peer: ' + s)

    def peer_error_no_client(self, client_id):
        self.peer_error(f'client {client_id} isn\'t subscribed to the chat service')



class IdGen:
    '''Generator of unique indentifiers of type `int`.'''

    def __init__(self):
        self._i = 0

    def gen(self):
        '''Returns an identifier that is different from all identifiers
        returned by this object earlier.'''
        r = self._i
        self._i += 1
        return r

@dataclass
class Msg:
    role: int
    msg: str

@dataclass
class HistoryMsg:
    '''A chat message in the form it is ransmitted in `HISTORY_RESP` net messages.'''
    session_id: int
    client_id: int
    msg: str

@dataclass
class Session:
    # idenitifier
    i: int

    '''The clients participating in this chat session. `clients[i]` is assigned role `i`.'''
    clients: (typing.Any, typing.Any) # (Client, Client)

    # messages of this chat session in the order they appeared in the chat session
    msgs: list[Msg] = field(default_factory = list)

@dataclass
class ClientSession:
    role: int
    session: Session

@dataclass
class Client:
    # idenitifier
    i: int

    key: bytes
    cookie: typing.Any = None # `bytes` or `None`
    temp_key: typing.Any = None # `bytes` or `None`
    socket0: socket.socket = None

    # active chat session in which this client participates
    active_session: ClientSession = None

    # inactive chat sessions
    sessions: list[ClientSession] = field(default_factory = list)

class Db:
    '''Exactly two clients participate in a chat session. Chat participants are assigned *roles*
    `0` and `1`. The client that requested a chat session is assigned role `0`,
    and the other participant is assigned role `1`.'''

    def __init__(self, clients):
        '''`clients` shall be the `clients` part of the server configuration.'''
        self.lock = threading.Lock()
        self._clients = dict((k, Client(i = k, key = v['key'])) for k, v in clients.items())
        self.session_id_gen = IdGen()

    def does_client_exist(self, client_id):
        '''Whether the client `client_id` exists in this database.'''
        return client_id in self._clients

    def set_cookie(self, client_id, cookie):
        '''The client `client_id` shall exist in this database.'''
        self._clients[client_id].cookie = cookie

    def cookie(self, client_id):
        '''The client `client_id` shall exist in this database.'''
        return self._clients[client_id].cookie

    def set_temp_key(self, client_id, temp_key):
        '''The client `client_id` shall exist in this database.'''
        self._clients[client_id].temp_key = temp_key

    def temp_key(self, client_id):
        '''The client `client_id` shall exist in this database.'''
        return self._clients[client_id].temp_key

    def client_key(self, client_id):
        '''The client `client_id` shall exist in this database.'''
        return self._clients[client_id].key

    def socket0(self, client_id):
        '''The client `client_id` shall exist in this database.'''
        return self._clients[client_id].socket0

    def is_client_reachable(self, client_id):
        '''Whether the client `client_id` exists in this database and is connected.'''
        return self.does_client_exist(client_id) and not(self._clients[client_id].socket0 is None)

    def is_client_in_session(self, client_id):
        '''Whether The client `client_id` participates in an active chat session.
        The client `client_id` shall exist in this database.'''
        return not(self._clients[client_id].active_session is None)

    def create_session(self, client_id0, client_id1):
        '''Creates a chat session whose participants are the clients `client_id0`
        and `client_id1`. Returns the identifier of the created chat session.
        The clients `client_id0` and `client_id1` shall exist in this database
        and shall not participate in an active chat session.'''
        session_id = self.session_id_gen.gen()
        client0 = self._clients[client_id0]
        client1 = self._clients[client_id1]
        session = Session(session_id, (client0, client1))
        client0.active_session = ClientSession(0, session)
        client1.active_session = ClientSession(1, session)
        return session_id

    def active_session(self, client_id):
        '''The identifier of the active chat session that the client `client_id` participates in.
        The client `client_id` shall exist in this database and shall participate
        in an active chat session.'''
        return self._clients[client_id].active_session.session.i

    def append_msg(self, client_id, msg):
        '''Appends chat message `msg` to the history of the active chat session
        that the client `client_id` participates in.
        `msg` shall be of type `str`.
        The client `client_id` shall exist in this database and shall participate
        in an active chat session.'''
        client_session = self._clients[client_id].active_session
        client_session.session.msgs.append(Msg(client_session.role, msg))

    def _client_peer(self, client_session):
        '''Returns the `Client` whose role in chat session `client_session.session`
        was not `client_session.role`.
        In other words, if `client_session` is taken from a `Client`, returns the `Client`
        which is the other participant of `client_session.session`.
        `client_session` shall be of type `ClientSession`.'''
        return client_session.session.clients[1 - client_session.role]

    def client_peer(self, client_id):
        '''Returns the identifier of the client who is the other participant
        in the active chat session that the client `client_id` participates in 
        The client `client_id` shall exist in this database and shall participate
        in an active chat session.'''
        return self._client_peer(self._clients[client_id].active_session).i

    def mark_connected(self, client_id, socket0):
        '''Marks the client `client_id` as connected. Clears the cookie of the client.
        Stores `socket0` in this database.
        The client `client_id` shall exist in this database and be not connected.
        This client shall be connected via `socket0`.'''
        client = self._clients[client_id]
        client.cookie = None
        client.socket0 = socket0

    def _end_session(self, client):
        '''Ends the active chat session that `client` participates in.
        `client` shall be of type `Client`. `client` shall participate in an active chat session.'''

        client_session = client.active_session

        client.sessions.append(client.active_session)
        client.active_session = None

        client1 = self._client_peer(client_session)
        client1.sessions.append(client1.active_session)
        client1.active_session = None

        return client1

    def end_session(self, client_id):
        '''Ends the active chat session that the client `client_id` participates in.
        The client `client_id` shall exist in this database and shall participate
        in an active chat session.'''
        return self._end_session(self._clients[client_id]).i

    def mark_disconnected(self, client_id):
        '''Marks the client `client_id` as disconnected.
        Ends an active chat session that the client `client_id` participates in if there is one.
        The client `client_id` shall exist in this database and be connected.'''
        client = self._clients[client_id]
        client.temp_key = None
        client.socket0 = None
        client_session = client.active_session
        if client_session is None:
            return None
        else:
            client1 = self._end_session(client)
            return (client1.i, client_session.session.i)

    def client_history(self, client_id, peer_client_id):
        '''Returns a Python generator which yields `HistoryMsg`s of all chat sessions
        such that the clients `client_id` and `peer_client_id` are the participants
        in the chat session.'''
        for client_session in self._clients[client_id].sessions:
            peer_client_id1 = self._client_peer(client_session).i
            if peer_client_id1 == peer_client_id:
                session= client_session.session
                for msg in client_session.session.msgs:
                    yield HistoryMsg(session.i, session.clients[msg.role].i, msg.msg)



class UdpThread(threading.Thread):
    def __init__(self, conf, db, logger):
        super().__init__()
        self.daemon = True
        self.conf = conf
        self.db = db
        self.logger = logger

    def run(self):
        with socket.socket(type = socket.SOCK_DGRAM) as udp_socket:
            udp_socket.bind((self.conf['host'], self.conf['udp_port']))

            '''This dictionary contains records with key `(peer, client_id)`
            and value `chal_nonce`. Such a record means that a randomly generated nonce `chal_nonce`
            was sent to the client at host `peer` with `client_id` in a net message `CHALLENGE`.
            `peer` is of the form `(IP_address, UDP_port)`.'''
            client_chals = dict()

            while True:
                (udp_packet, peer) = udp_socket.recvfrom(CLIENT_MSG_SIZE_LIMIT)
                msg = parse_client_msg(udp_packet)
                def send(msg):
                    udp_socket.sendto(render_server_msg(msg), peer)
                if isinstance(msg, HelloMsg):
                    client_id = msg.client_id
                    does_client_exist = None
                    with self.db.lock:
                        does_client_exist = self.db.does_client_exist(client_id)
                    if does_client_exist:
                        chal_nonce = os.urandom(CHAL_NONCE_SIZE)
                        client_chals[(peer, client_id)] = chal_nonce
                        send(ChalMsg(chal_nonce))
                    else:
                        self.logger.peer_error_no_client(client_id)
                        send(AuthFailMsg())
                elif isinstance(msg, ResponseMsg):
                    client_id = msg.client_id
                    chal_id = (peer, client_id)
                    if not(chal_id in client_chals):
                        self.logger.peer_error(f'client {client_id} at host {peer}'\
                                + ' sent a Response message without a corresponding earlier'\
                                + ' Challenge message')
                    else:
                        k = None
                        with self.db.lock:
                            client_key = self.db.client_key(client_id)
                            chal_nonce = client_chals[chal_id]
                            if mac_a3(client_key, chal_nonce) != msg.sign:
                                def k1():
                                    self.logger.peer_error(f'client {client_id} sent'\
                                            + ' a Response message with an incorrect signature')
                                    send(AuthFailMsg())
                                k = k1
                            else:
                                cookie = os.urandom(COOKIE_SIZE)
                                self.db.set_cookie(client_id, cookie)
                                temp_key = mac_a8(client_key, chal_nonce)
                                self.db.set_temp_key(client_id, temp_key)
                                def k1():
                                    del client_chals[chal_id]
                                    self.logger.peer_info(f'client {client_id} has'\
                                            + ' authenticated successfully')
                                    msg = struct.pack('<' + AUTH_SUCCESS_FORMAT,\
                                            cookie, self.conf['tcp_port'])
                                    send(AuthSuccessMsg(my_encrypt(temp_key, msg)))
                                k = k1
                        k()
                else:
                    self.logger.peer_error(f'unexpected message {msg}')

class TcpThread(threading.Thread):
    def __init__(self, tcp_client_socket, db, logger):
        super().__init__()
        self.daemon = True
        self.socket0 = tcp_client_socket
        self.db = db
        self.logger = logger

    def handle_loop_msg(self, send, send_to, client_id, msg):
        if isinstance(msg, ChatReqMsg):
            client_id1 = msg.client_id
            def unreachable():
                send(UnreachableMsg(client_id1))
            with self.db.lock:
                if not(self.db.is_client_reachable(client_id1)):
                    self.logger.peer_error(f'client {client_id1} is unreachable')
                    unreachable()
                elif client_id1 == client_id:
                    self.logger.peer_error(f'client {client_id} tries to chat with themselves')
                    unreachable()
                elif self.db.is_client_in_session(client_id):
                    self.logger.peer_error(f'client {client_id} already chats')
                    unreachable()
                elif self.db.is_client_in_session(client_id1):
                    self.logger.peer_error(f'client {client_id1} already chats')
                    unreachable()
                else:
                    session_id = self.db.create_session(client_id, client_id1)
                    send(ChatStartedMsg(session_id, client_id1))
                    send_to(client_id1, ChatStartedMsg(session_id, client_id))
        elif isinstance(msg, EndReqMsg):
            with self.db.lock:
                if not(self.db.is_client_in_session(client_id)):
                    self.logger.peer_error(f'client {client_id} tries to end a session'\
                            + ' while not in a session')
                else:
                    session_id = self.db.active_session(client_id)
                    if msg.session_id != session_id:
                        self.logger.peer_error(f'client {client_id} isn\'t in session {session_id}')
                    else:
                        client_id1 = self.db.end_session(client_id)
                        send_to(client_id1, EndNotifMsg(session_id))
        elif isinstance(msg, ChatMsg):
            with self.db.lock:
                if not(self.db.is_client_in_session(client_id)):
                    self.logger.peer_error(f'client {client_id} tries to chat'\
                            + ' while not in a session')
                else:
                    session_id = self.db.active_session(client_id)
                    if msg.session_id != session_id:
                        self.logger.peer_error(f'client {client_id} tries to chat'\
                                + f' in wrong session {msg.session_id}')
                    else:
                        self.db.append_msg(client_id, msg.msg)
                        send_to(self.db.client_peer(client_id), ChatMsg(session_id, msg.msg))
        elif isinstance(msg, HistoryReqMsg):
            with self.db.lock:
                for history_msg in self.db.client_history(client_id, msg.client_id):
                    send(HistoryRespMsg(history_msg.session_id, history_msg.client_id,\
                            history_msg.msg))
        else:
            self.logger.peer_error(f'unexpected message {msg}')

    def run(self):
        try:
            reader = SocketReader(self.socket0)
            try:
                format = '<' + CLIENT_ID_FORMAT
                (client_id,) = struct.unpack(format, reader.read(struct.calcsize(format)))
                temp_key = None
                cookie = None
                with self.db.lock:
                    if self.db.does_client_exist(client_id):
                        temp_key = self.db.temp_key(client_id)
                        cookie = self.db.cookie(client_id)
                if cookie is None:
                    self.logger.peer_error(f'client {client_id} has no cookie set')
                else:
                    def send(msg):
                        return send_tcp(self.socket0, temp_key, render_server_msg(msg))
                    def send_to(client_id, msg):
                        return send_tcp(self.db.socket0(client_id), self.db.temp_key(client_id),\
                                render_server_msg(msg))
                    msg = parse_client_msg(parse_tcp(temp_key, reader))
                    if not(isinstance(msg, ConnectMsg)):
                        self.logger.peer_error('a Connect message is expected')
                    elif msg.cookie != cookie:
                        self.logger.peer_error(f'client {client_id} sent an incorrect cookie')
                    else:
                        self.logger.peer_info(f'client {client_id} has connected via TCP')
                        with self.db.lock:
                            self.db.mark_connected(client_id, self.socket0)
                            send(ConnectedMsg())
                        try:
                            while True:
                                self.handle_loop_msg(send, send_to, client_id,\
                                        parse_client_msg(parse_tcp(temp_key, reader)))
                        finally:
                            with self.db.lock:
                                r = self.db.mark_disconnected(client_id)
                                if not(r is None):
                                    (client_id1, session_id) = r
                                    send_to(client_id1, EndNotifMsg(session_id))
            except SocketReaderClosed:
                self.logger.peer_info(f'client has disconnected')
        finally:
            self.socket0.close()

def main_net(conf):
    '''Accepts incoming TCP connections.'''
    logger = Logger()
    db = Db(conf['clients'])
    UdpThread(conf, db, logger).start()
    with socket.socket(type = socket.SOCK_STREAM) as server_tcp_socket:
        server_tcp_socket.bind((conf['host'], conf['tcp_port']))
        server_tcp_socket.listen()
        while True:
            (client_tcp_socket, _) = server_tcp_socket.accept()
            try:
                TcpThread(client_tcp_socket, db, logger).start()
            except Exception as e:
                client_tcp_socket.close()
                logger.error('failed to start a TCP reading thread')
                logger.error(str(e))

def main():
    '''Parses a configuration file.'''
    try:
        [_, conf] = sys.argv
        with open(conf, 'r') as file0:
            try:
                conf = json.load(file0)
                def client_parse(client):
                    client['key'] = base64.standard_b64decode(client['key'])
                    return client
                conf['clients'] = dict((int(k), client_parse(v))\
                        for k, v in conf['clients'].items())
                main_net(conf)
            except ValueError as e:
                print('ERROR: invalid configuration file: ' + str(e), file = sys.stderr)
    except ValueError:
        print('Usage: $this_program $path_to_configuration_file')
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    main()
