---
title: "Server Based Chat"
subtitle: "Report"
---



# Protocol

## Connection phase

During the connection phase, the server authenticates the client.
Authentication is based on the challenge/response mechanism.
In other words, the client proves its identity by providing the server a response
only the client can generate. For every pair of a client and a server,
there is a separate symmetric secret key `K`. `K` is known to the client's user
and the server's administrator. The server's administrator knows who is the other owner of `K`
from a trusted source. `K` is used for authentication.

When the server receives message `HELLO(Client-ID-A)` message
from client `Client-ID-A` that is subscribed to the chat service,
the server randomly generates `chal_nonce` and sends message `CHALLENGE(chal_nonce)` to the client.
The client sends message `RESPONSE(Client-ID-A, mac_a3(K, chal_nonce))` to the server.
`mac_a3(K, X)` equals `hash1(X + K)` where `hash1` is SHA-2 SHA-256 cryptographic hash function.
If and only if the server receives message `RESPONSE(Client-ID-A, H)`
such that `H == mac_a3(K, chal_nonce)`, the server decides that the owner of `K` is authenticated
as `Client-ID-A`. Only the owner of `K` (and the server, of course) can generate such a `RESPONSE`.

If the server authenticates the client, the server starts a client session
protected by symmetric key `mac_a8(K, chal_nonce)`.
This symmetric key will be called the *temporary key* below.
`mac_a8(K, X)` equals `hash1(nonce0 + X + nonce1 + K + nonce2)`.
`nonce0`, `nonce1`, and `nonce2` were randomly generated and are fixed in the source code.
This is done so `mac_a8` is different from `mac_a3`. If `mac_a8` equalled `mac_a3`,
the client would send the temporary key in the clear.
Functions `mac_a3` and `mac_a8` are implemented in “common.py”.

If the client is authenticated, the server sends message `AUTH_SUCCESS(cookie, tcp_port)`
encrypted by the temporary key to the client.
`tcp_port` is fixed in the source code of the server.
The client establishes a TCP connection to the server's port `tcp_port`
and sends message `CONNECT(cookie)` encrypted by the temporary key via this connection.
Since all clients connect to the same TCP port, and message `CONNECT` is encrypted,
the server has no way to determine which client is connected through TCP
other than trying to decrypt the message with all recently created temporary keys.
Hence this server implements a protocol slightly different from the suggested protocol
in order to make the protocol more efficient. In particular, the client additionally sends
its identifier in the clear at the start of a TCP connection.

The client protocol state diagram of the connection phase
and the sequence diagram of the connection phase are shown in the assignment handout.

![Server protocol state diagram of the connection phase](state-conn-server.png)

In the server protocol state diagram of the connection phase above,
incorrect `RESPONSE` doesn't change the state because an attacker can send such a message.
We shouldn't let the attacker disrupt the authentication process of a legitimate user.

## Chat phase

The client protocol state diagram of the chat phase is shown in the assignment handout.

![Server protocol state diagram of the chat phase](state-chat-server.png)

![Sequence diagram of the unsuccessful chat phase](seq-chat-unsuccessful.png)

![Sequence diagram of the successful chat phase](seq-chat-successful.png)



# Issues

While implementing this project, the team encountered the following issues.

- The client program executes two threads. The main thread listens to `stdin`,
  and `TcpThread` listens to a TCP socket connected to the server.
  If a user types “Log off”, the main thread needs to terminate `TcpThread`
  which is blocked in the `recv` call to the TCP socket.
  A common way to do it is to shut down the reading end of the TCP socket from the main thread
  by executing `tcp_socket.shutdown(socket.SHUT_RD)`;
  see [this answer on StackOverflow](https://stackoverflow.com/a/58963160/793392).
  Unfortunately, the `shutdown` system call is forbidden.
  In the current implementation, the socket is shut down by the OS
  when the client process terminates. `TcpThread` is terminated because it's a daemon thread
  and the main thread terminates. The same issue exists in the server program.
- With the suggested protocol, the system may lose chat messages
  sent just before ending a chat session. A sequence diagram of such a scenario is shown below.
  While this scenario wasn't encountered when testing the system, it's possible to demonstrate it
  if the latency of the network is high.
- With the suggested protocol, the server needs to try all temporary keys
  when binding a TCP session to a client; see Section “Connection phase”.
- Message `HISTORY_RESP` contains only a client identifier and a text,
  while it is required to also show the chat session identifier of the chat message to a user.
  Hence a modified version of `HISTORY_RESP` was implemented. In particular,
  the field for the chat session identifier was added to `HISTORY_RESP`.

![Sequence diagram of the scenario with a lost chat message](seq-chat-lost.png)
